import Pages.*;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.json.JSONObject;
import org.junit.After;
import org.junit.jupiter.api.BeforeAll;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;
import java.util.Objects;
import java.util.concurrent.TimeUnit;


public class Test{
    private static LoginPage loginPage;
    private static SendMessagePage sendMessagePage;
    private static LogoutPage logoutPage;
    private static ChangeThemePage changeThemePage;
    private static NoNotifPage noNotifPage;
    private static AppiumDriver driver;

    private DesiredCapabilities capabilities;

    @BeforeAll
    public static void setUp() {
        Test test = new Test();
        switch (Configuration.PLATFORM) {
            case ANDROID:
                test.setAndroidCapabilities();
            case IOS:
                test.setIOSCapabilities();
                break;
            default:
                throw new RuntimeException("Incorrect platform");
        }
        changeThemePage = new ChangeThemePage(driver);
        sendMessagePage = new SendMessagePage(driver);
        loginPage = new LoginPage(driver);
        logoutPage = new LogoutPage(driver);
        noNotifPage =new NoNotifPage(driver);
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    }

    private void setIOSCapabilities() {
        this.capabilities = new DesiredCapabilities();
        JSONObject appiumJson = JSONService.readJsonFromFile(this.getClass().getClassLoader().getResource("capabilities/iosSim.json").getPath());
        JSONObject caps = JSONService.getCapabilities(appiumJson);
        caps.keySet().forEach(keyStr -> this.capabilities.setCapability(keyStr, caps.get(keyStr)));
        try {
            driver = new IOSDriver(new URL(JSONService.getUrl(appiumJson)), this.capabilities);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    private void setAndroidCapabilities() {
        this.capabilities = new DesiredCapabilities();
        JSONObject appiumJson = JSONService.readJsonFromFile(Objects.requireNonNull("src\\test\\resources\\capabilities\\browserStack.json"));
        assert appiumJson != null;
        JSONObject caps = JSONService.getCapabilities(appiumJson);
        assert caps != null;
        caps.keySet().forEach(keyStr -> this.capabilities.setCapability(keyStr, caps.get(keyStr)));
        try {
            driver = new AndroidDriver(new URL(JSONService.getUrl(appiumJson)), this.capabilities);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @org.junit.jupiter.api.Test
    public void Test() throws InterruptedException {
        logIn();
        messageSend();
        changeTheme();
        noNotif();
        logOut();
    }

    public void logIn(){
        loginPage.input1Click();
        loginPage.input2Click();
        loginPage.buttonClick();
        //loginPage.swipeDown();
        //loginPage.swipeUp();
    }

    public void logOut(){
        logoutPage.logoutLinkClick();
        logoutPage.AlertButtonClick();
    }

    public void messageSend(){
       sendMessagePage.discIconClick();
       sendMessagePage.messageBtnClick();
       sendMessagePage.TochkiClick();
       sendMessagePage.createChatClick();
       sendMessagePage.createEmptyClick();
       sendMessagePage.cancelClick();
       sendMessagePage.msgClick();
       sendMessagePage.addClick();
       sendMessagePage.allowClick();
       sendMessagePage.pictureClick();
       sendMessagePage.sendClick();
       sendMessagePage.deleteClick();
       sendMessagePage.deleteOkClick();
       sendMessagePage.deleteSendClick();
       changeThemePage.backClick();
       sendMessagePage.lentaBtnClick();
    }

    public void changeTheme(){
        changeThemePage.menuClick();
        changeThemePage.settingsClick();
        changeThemePage.deviceSettingsClick();
        changeThemePage.externalSettingsClick();
        changeThemePage.themeSettingsClick();
        changeThemePage.darkSettingsClick();
        changeThemePage.themeSettingsClick();
        changeThemePage.defaultSettingsClick();
        changeThemePage.backClick();
        changeThemePage.backClick();
    }

    public void noNotif(){
        noNotifPage.notificationClick();
        noNotifPage.pushClick();
        noNotifPage.notifyClick();
        noNotifPage.hourClick();
        changeThemePage.backClick();
        changeThemePage.backClick();
    }

    @After
    public void tearDown() {
        driver.quit();
    }
}
