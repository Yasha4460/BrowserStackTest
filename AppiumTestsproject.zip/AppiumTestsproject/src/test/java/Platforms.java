public enum Platforms {
    ANDROID,
    IOS
}
