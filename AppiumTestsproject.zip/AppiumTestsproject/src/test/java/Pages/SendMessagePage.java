package Pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class SendMessagePage {

    protected AppiumDriver driver;

    public SendMessagePage(AppiumDriver driver){
        this.driver=driver;
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void waitDuration(WebElement webElement){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOf(webElement));
    }


    @AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Discussions\"]/android.widget.ImageView")
    private WebElement discIcon;

    @AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"News Feed\"]/android.widget.ImageView")
    private WebElement lentaClick;

    @AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Messages\"]/android.widget.ImageView")
    private WebElement messageBtn;

    @AndroidFindBy(id="ru.ok.android:id/ab_overflow")
    private WebElement Tochki;

    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")
    private WebElement createChat;

    @AndroidFindBy(id="ru.ok.android:id/contacts_multi_picker_fragment__b_action_button")
    private WebElement createEmpty;

    @AndroidFindBy(id="ru.ok.android:id/md_buttonDefaultNegative")
    private WebElement cancel;

    @AndroidFindBy(id="ru.ok.android:id/new_message_text")
    private WebElement msgText;

    @AndroidFindBy(id="ru.ok.android:id/create_message__attach_media_container")
    private WebElement add;

    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[1]")
    private WebElement picture;

    @AndroidFindBy(xpath=".//*[@text='ALLOW']")
    private WebElement allow;

    @AndroidFindBy(id="ru.ok.android:id/bottom_panel_action_btn")
    private WebElement send;

    @AndroidFindBy(id="ru.ok.android:id/bottom_panel_action_btn")
    private WebElement message;

    @AndroidFindBy(id="ru.ok.android:id/view_message__tv_text")
    private WebElement delete;

    @AndroidFindBy(id="ru.ok.android:id/message_context_menu_delete")
    private WebElement deleteOk;

    @AndroidFindBy(id="ru.ok.android:id/md_buttonDefaultPositive")
    private WebElement deleteSend;


    public void messageBtnClick(){
        waitDuration(messageBtn);
        messageBtn.click();
    }

    public void lentaBtnClick(){
        waitDuration(lentaClick);
        lentaClick.click();
    }

    public void discIconClick(){
        waitDuration(discIcon);
        discIcon.click();
    }


    public void TochkiClick(){
        waitDuration(Tochki);
        Tochki.click();
    }

    public void createChatClick(){
        waitDuration(createChat);
        createChat.click();
    }

    public void createEmptyClick(){
        waitDuration(createEmpty);
        createEmpty.click();
    }

    public void cancelClick(){
        waitDuration(cancel);
        cancel.click();
    }

    public void msgClick(){
        waitDuration(msgText);
        msgText.sendKeys("Hello");
    }

    public void addClick(){
        waitDuration(add);
        add.click();
    }

    public void allowClick(){
        waitDuration(allow);
        allow.click();
    }

    public void pictureClick(){
        waitDuration(picture);
        picture.click();
    }

    public void sendClick(){
        waitDuration(send);
        send.click();
    }

    public void deleteClick(){
        waitDuration(delete);
        delete.click();
    }

    public void deleteOkClick(){
        waitDuration(deleteOk);
        deleteOk.click();
    }

    public void deleteSendClick(){
        waitDuration(deleteSend);
        deleteSend.click();
    }
}
