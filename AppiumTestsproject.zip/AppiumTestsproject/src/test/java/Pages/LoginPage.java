package Pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {

    protected AppiumDriver driver;

    public LoginPage(AppiumDriver driver){
        this.driver=driver;
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void wait(WebElement webElement){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOf(webElement));
    }

    @AndroidFindBy(id = "ru.ok.android:id/text_login")
    public WebElement input1;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.EditText")
    public WebElement input2;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.Button")
    public WebElement button;

    public void input1Click() {
        wait(input1);
        input1.sendKeys("");

    }

    public void input2Click() {
        wait(input2);
        input2.sendKeys("");
    }

    public void buttonClick() {
        wait(button);
        button.click();
    }

    //    public void swipeDown() throws InterruptedException {
//        SelenideElement recommendedGroups = SelenideAppium.$x(".//*[@text='Recommended groups']");
//        wait(recommendedGroups);
//        SelenideAppium.$x(".//*[@text='Add friends from your phone’s contacts']")
//                .scroll(with(DOWN, 1)).wait(30000);
//        SelenideAppium.$x(".//*[@text='Popular search requests']")
//                .scroll(down()).shouldHave(visible).wait(3000);
//    }
//    public void swipeUp()y
//    {
//        SelenideElement popularRequests = SelenideAppium.$x(".//*[@text='Popular search requests']");
//        wait(popularRequests);
//        SelenideAppium.$x(".//*[@text='Add friends from your phone’s contacts']")
//                .scroll(with(UP, 1));
//        SelenideAppium.$x(".//*[@text='Recommended groups']")
//                .scroll(up()).shouldHave(visible);
//    }

}
