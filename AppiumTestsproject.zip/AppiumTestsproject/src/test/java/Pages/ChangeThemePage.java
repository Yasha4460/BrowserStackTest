package Pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ChangeThemePage {

    protected AppiumDriver driver;

    public ChangeThemePage(AppiumDriver driver){
        this.driver=driver;
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void waitDuration(WebElement webElement){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOf(webElement));
    }



    @AndroidFindBy(xpath="//android.widget.ImageButton[@content-desc=\"Open side menu\"]")
    private WebElement menu;
    @AndroidFindBy(xpath="(//android.view.ViewGroup[@content-desc=\"Menu\"])[1]/android.widget.ImageView")
    private WebElement setting;

    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.LinearLayout/android.view.ViewGroup/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[3]")
    private WebElement deviceSettings;

    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.LinearLayout/android.view.ViewGroup/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[3]")
    private WebElement externalSettings;
    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.LinearLayout/android.view.ViewGroup/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[2]")
    private WebElement themeSettings;

    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[2]")
    private WebElement darkTheme;

    @AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[3]")
    private WebElement defaultTheme;

    @AndroidFindBy(xpath="//android.widget.ImageButton[@content-desc=\"Navigate up\"]")
    private WebElement back;

    public void menuClick(){
        waitDuration(menu);
        menu.click();
    }
    public void settingsClick(){
        waitDuration(setting);
        setting.click();
    }
    public void deviceSettingsClick(){
        waitDuration(deviceSettings);
        deviceSettings.click();
    }

    public void externalSettingsClick(){
        waitDuration(externalSettings);
        externalSettings.click();
    }
    public void themeSettingsClick(){
        waitDuration(themeSettings);
        themeSettings.click();
    }
    public void darkSettingsClick(){
        waitDuration(darkTheme);
        darkTheme.click();
    }
    public void defaultSettingsClick(){
        waitDuration(defaultTheme);
        defaultTheme.click();
    }
    public void backClick(){
        waitDuration(back);
        back.click();
    }




}

