public class Configuration {
    public static final Platforms PLATFORM = Platforms.ANDROID;
}
